<?php
$rootPath = '../';
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$recordId = $_GET['id'] ?? null;

if (!$recordId) {
    header("Location: history.php");
    exit;
}

// Verify the record belongs to the user
$stmt = $conn->prepare("SELECT id FROM sleep_records WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $recordId, $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: history.php");
    exit;
}

// Delete the record
$deleteStmt = $conn->prepare("DELETE FROM sleep_records WHERE id = ? AND user_id = ?");
$deleteStmt->bind_param("ii", $recordId, $userId);
$deleteStmt->execute();
$deleteStmt->close();

// Redirect back to history
header("Location: history.php?deleted=1");
exit;
?>