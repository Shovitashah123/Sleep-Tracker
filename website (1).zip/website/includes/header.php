<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'SleepTrack') ?> — SleepTrack</title>
    <link rel="stylesheet" href="<?= $rootPath ?>assets/style.css">
</head>
<body>